# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/Sec:para/;
$ref_files{$key} = "$dir".q|node10.html|; 
$noresave{$key} = "$nosave";

1;

