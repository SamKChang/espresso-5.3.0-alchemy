rm -r results
rm difference ld1.wfc*
